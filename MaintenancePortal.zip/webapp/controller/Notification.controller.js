sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/routing/History",
	"jquery.sap.global",
	"sap/ui/model/Filter"
], function(Controller, JSONModel, MessageToast, History, jQuery, Filter) {
	"use strict";

	return Controller.extend("MaintenancePortal.controller.Notification", {

		onInit: function() {
			var oJSONModel = new JSONModel();
			this.getView().setModel(oJSONModel, "jsonmodel");
			var sUrl = "/sap/opu/odata/sap/ZODATA_PM_900343_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			this.getView().setModel(oModel);
			oModel.read("/NotificationListSet", {
				success: function(data) {
					oJSONModel.setData({
						NotificationListSet: data.results
					});
				}
			});
		},

		onSearch: function(oEvt) {

			// add filter for search
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var oFilter = new Filter({
					filters: [
						new Filter("NotifType", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("Priotype", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("Funcloc", sap.ui.model.FilterOperator.Contains, sQuery)
					]
				});
			}

			// update list binding
			var list = this.getView().byId("List");
			var binding = list.getBinding("items");
			binding.filter(oFilter, "Application");
		},

		onPress: function(oEvent) {
			this.getselval1 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Notificat;
			this.getView().byId("input1").setValue(this.getselval1);
			this.getselval2 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().NotifType;
			this.getView().byId("input2").setValue(this.getselval2);
			this.getselval3 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Descript;
			this.getView().byId("input3").setValue(this.getselval3);
			this.getselval4 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Funcloc;
			this.getView().byId("input4").setValue(this.getselval4);
			this.getselval5 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Funcldescr;
			this.getView().byId("input5").setValue(this.getselval5);
			this.getselval6 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Priority;
			this.getView().byId("input6").setValue(this.getselval6);
			this.getselval7 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Priotype;
			this.getView().byId("input7").setValue(this.getselval7);
			this.getselval8 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().SStatus;
			this.getView().byId("input8").setValue(this.getselval8);
			this.getselval9 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Notifdate.toISOString().slice(0, 10);
			this.getView().byId("input9").setValue(this.getselval9);
			this.getselval10 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Equipment;
			this.getView().byId("input10").setValue(this.getselval10);
			this.getselval11 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Equidescr;
			this.getView().byId("input11").setValue(this.getselval11);
			this.getselval12 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PlanPlant;
			this.getView().byId("input12").setValue(this.getselval12);
			this.getselval13 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PlanGroup;
			this.getView().byId("input13").setValue(this.getselval13);
			this.getselval14 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Customer;
			this.getView().byId("input14").setValue(this.getselval14);
			this.getselval15 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PurchNo;
			this.getView().byId("input15").setValue(this.getselval15);
			this.getselval16 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PurchDate;
			this.getView().byId("input16").setValue(this.getselval16);
			this.getselval17 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().ExternalNumber;
			this.getView().byId("input17").setValue(this.getselval17);
			this.getselval18 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Startdate.toISOString().slice(0, 10);
			this.getView().byId("input18").setValue(this.getselval18);
			this.getselval19 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Enddate.toISOString().slice(0, 10);
			this.getView().byId("input19").setValue(this.getselval19);
			this.getselval20 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Completion;
			this.getView().byId("input20").setValue(this.getselval20);

		},

		toHome: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Home");
		},

		toSubmodules: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PM_Submodules");
		},

		toLoginPage: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("LoginPage");
		},

		onBack: function() {
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("Home");
			}
		}

	});
});