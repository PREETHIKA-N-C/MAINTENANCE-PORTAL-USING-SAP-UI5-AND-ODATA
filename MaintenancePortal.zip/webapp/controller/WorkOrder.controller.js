sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"jquery.sap.global",
	"sap/ui/model/Filter"
], function(Controller, History, JSONModel, MessageToast, jQuery, Filter) {
	"use strict";

	return Controller.extend("MaintenancePortal.controller.WorkOrder", {

		onInit: function() {
			var oJSONModel = new JSONModel();
			this.getView().setModel(oJSONModel, "jsonmodel");
			var sUrl = "/sap/opu/odata/sap/ZODATA_PM_900343_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			this.getView().setModel(oModel);
			oModel.read("/WorkOrderListSet?$filter=Plant eq '0001'&$format=json", {
				success: function(data) {
					oJSONModel.setData({
						WorkOrderListSet: data.results
					});
				}
			});
		},
		onSearch: function(oEvt) {

			// add filter for search
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var oFilter = new Filter({
					filters: [
						new Filter("OrderType", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("Priotype", sap.ui.model.FilterOperator.Contains, sQuery),
						new Filter("Funcloc", sap.ui.model.FilterOperator.Contains, sQuery)
					]
				});
			}

			// update list binding
			var list = this.getView().byId("wolist");
			var binding = list.getBinding("items");
			binding.filter(oFilter, "Application");
		},

		onPress: function(oEvent) {
			this.getselval1 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Orderid;
			this.getView().byId("input1").setValue(this.getselval1);
			this.getselval2 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().OrderType;
			this.getView().byId("input2").setValue(this.getselval2);
			this.getselval3 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Description;
			this.getView().byId("input3").setValue(this.getselval3);
			this.getselval4 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Funcloc;
			this.getView().byId("input4").setValue(this.getselval4);
			this.getselval5 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Funcldescr;
			this.getView().byId("input5").setValue(this.getselval5);
			this.getselval6 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Priority;
			this.getView().byId("input6").setValue(this.getselval6);
			this.getselval7 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Priotype;
			this.getView().byId("input7").setValue(this.getselval7);
			this.getselval8 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PriotypeDesc;
			this.getView().byId("input8").setValue(this.getselval8);
			this.getselval9 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().SStatus;
			this.getView().byId("input9").setValue(this.getselval9);
			this.getselval10 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Planplant;
			this.getView().byId("input10").setValue(this.getselval10);
			this.getselval11 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().LocPlant;
			this.getView().byId("input11").setValue(this.getselval11);
			this.getselval12 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Plangroup;
			this.getView().byId("input12").setValue(this.getselval12);
			this.getselval13 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().WorkCntr;
			this.getView().byId("input13").setValue(this.getselval13);
			this.getselval14 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().WorkActivity;
			this.getView().byId("input14").setValue(this.getselval14);
			this.getselval15 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().WorkActual;
			this.getView().byId("input15").setValue(this.getselval15);
			this.getselval16 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Location;
			this.getView().byId("input16").setValue(this.getselval16);
			this.getselval17 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().UnWork;
			this.getView().byId("input17").setValue(this.getselval17);
			this.getselval18 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Equipment;
			this.getView().byId("input18").setValue(this.getselval18);
			this.getselval19 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Equidescr;
			this.getView().byId("input19").setValue(this.getselval19);
			this.getselval20 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Activity;
			this.getView().byId("input20").setValue(this.getselval20);
			this.getselval21 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().SubActivity;
			this.getView().byId("input21").setValue(this.getselval21);
			this.getselval22 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Acttype;
			this.getView().byId("input22").setValue(this.getselval22);
			this.getselval23 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PercentOfWork;
			this.getView().byId("input23").setValue(this.getselval23);
			this.getselval24 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Sortfield;
			this.getView().byId("input24").setValue(this.getselval24);
			this.getselval25 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().PersonNo;
			this.getView().byId("input25").setValue(this.getselval25);
			this.getselval26 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().ControlKey;
			this.getView().byId("input26").setValue(this.getselval26);
			this.getselval27 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().EarlSchedStartDate.toISOString().slice(0, 10);
			this.getView().byId("input27").setValue(this.getselval27);
			this.getselval28 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().LateSchedStartDate.toISOString().slice(0, 10);
			this.getView().byId("input28").setValue(this.getselval28);
			this.getselval29 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().EarlSchedFinishDate.toISOString().slice(0, 10);
			this.getView().byId("input29").setValue(this.getselval29);
			this.getselval30 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().LateSchedFinDate.toISOString().slice(0, 10);
			this.getView().byId("input30").setValue(this.getselval30);
			this.getselval31 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Material;
			this.getView().byId("input31").setValue(this.getselval31);
			this.getselval32 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().MatlDesc;
			this.getView().byId("input32").setValue(this.getselval32);
			this.getselval33 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().MaterialExternal;
			this.getView().byId("input33").setValue(this.getselval33);
			this.getselval34 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().NotifNo;
			this.getView().byId("input34").setValue(this.getselval34);
			this.getselval35 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().CalculationKey;
			this.getView().byId("input35").setValue(this.getselval35);
			this.getselval36 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().Counter;
			this.getView().byId("input36").setValue(this.getselval36);
			this.getselval37 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().RoutingNo;
			this.getView().byId("input37").setValue(this.getselval37);
			this.getselval38 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().ConfNo;
			this.getView().byId("input38").setValue(this.getselval38);
			this.getselval39 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().ActualStartDate.toISOString().slice(0, 10);
			this.getView().byId("input39").setValue(this.getselval39);
			this.getselval40 = oEvent.getSource().getSelectedItem().
			getBindingContext("jsonmodel").getObject().ActualFinDate.toISOString().slice(0, 10);
			this.getView().byId("input40").setValue(this.getselval40);

		},

		toHome: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Home");
		},

		toSubmodules: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PM_Submodules");
		},

		toLoginPage: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("LoginPage");
		},

		onBack: function() {
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("Home");
			}
		}

	});

});