sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/BindingMode",
	"sap/m/MessageToast"
], function(Controller, JSONModel, BindingMode, MessageToast) {
	"use strict";

	return Controller.extend("MaintenancePortal.controller.LoginPage", {

		onLoginTap: function() {
			var empid = this.getView().byId("empid").getValue();
			var passwd = this.getView().byId("passwd").getValue();
			var sUrl = "/sap/opu/odata/sap/ZODATA_PM_900343_SRV/";
			var oModel1 = new sap.ui.model.odata.ODataModel(sUrl, true);
			var rUrl = "LoginCredentialsSet('" + empid + "')?$format=json";
			var oDataempId;
			var oDatapass;
			oModel1.read(rUrl, {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					oDataempId = oData.WfEmployeeid;
					oDatapass = oData.WfPassword;
				}
			});

			if (empid === oDataempId && passwd === oDatapass) {
				MessageToast.show("Login Success");
				$(".sapMMessageToast").css("background", "#4cba6b");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("MaintenancePortal");

			} else {
				MessageToast.show("Login Failed");
				$(".sapMMessageToast").css("background", "#cc1919");
			}

			var oData = [{
				"empid": oDataempId,
				"pass": oDatapass
			}];
			var oModel2 = new JSONModel(oData);
			this.getView().setModel(oModel2);

		}

	});
});